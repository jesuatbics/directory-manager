﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Directory.Data
{
    public class DirectoryContext :DbContext
    {
        public DirectoryContext(DbContextOptions<DirectoryContext> options)
           : base(options)
        {
        }

        public DbSet<Teacher> Teachers { get; set; }
       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Teacher>().ToTable("Teacher");
          
        }

    }
}
