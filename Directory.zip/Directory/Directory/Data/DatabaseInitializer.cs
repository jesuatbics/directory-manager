﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Directory.Data
{
    public class DatabaseInitializer
    {
        public static void Initialize(DirectoryContext context)
        {
            context.Database.EnsureCreated();

            var teachers = new Teacher[]
            {
                new Teacher{FirstName ="Teacher 1",LastName="Teacher",Email="teacher@gmail.com", PhoneNumber="123456789", RoomNumber="1"},
            };

            context.Teachers.AddRange(teachers);
            context.SaveChanges();
        }
    }
}
