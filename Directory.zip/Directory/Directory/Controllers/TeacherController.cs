﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Directory.Data;
using Directory.Models;
using Directory.Views.Teacher;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;


// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Directory.Controllers
{
    public class TeacherController : Controller
    {
        private readonly Directory.Data.DirectoryContext _context;
        private IHostingEnvironment Environment;
        private IConfiguration Configuration;
        public TeacherController(Directory.Data.DirectoryContext context, IHostingEnvironment _environment, IConfiguration _configuration)
        {
            _context = context;
            Environment = _environment;
            Configuration = _configuration;
        }
        // GET: /<controller>/
        public IActionResult List()
        {
            return View(GetTeachers());
        }

        private List<TeacherModel> GetTeachers()
        {
            return _context.Teachers.Select(x => new TeacherModel { Id = x.Id, FirstName = x.FirstName, LastName = x.LastName, Email = x.Email, PhoneNumber = x.PhoneNumber }).ToList();
        }

        public IActionResult Test()
        {
            ViewData["Title"] = "Create";
            return View(new TestModel());
        }

        public IActionResult Details(int id)
        {
            ViewData["Title"] = "Details";
            var teacher = _context.Teachers.Find(id);
            if (teacher != null)
            {
                string path = Path.Combine(this.Environment.WebRootPath, "Profiles");
                string profilePath = string.Format("/Profiles/{0}", string.IsNullOrWhiteSpace(teacher.ProfilePicture) ? "Default.png" : teacher.ProfilePicture);
                var teacherModel = new TeacherModel
                {
                    FirstName = teacher.FirstName,
                    LastName = teacher.LastName,
                    Email = teacher.Email,
                    PhoneNumber = teacher.PhoneNumber,
                    RoomNumber = teacher.RoomNumber,
                    ProfilePicture = profilePath,
                    SubjectTaught = teacher.SubjectTaught
                };
                return View(teacherModel);
            }
            return View(new TeacherModel());
        }
        public IActionResult Search(string searchText)
        {
            List<TeacherModel> searchResult = new List<TeacherModel>();
            if (!string.IsNullOrWhiteSpace(searchText))
            {
                IQueryable<Teacher> searchResults = _context.Teachers.Where(x => x.LastName.StartsWith(searchText) || x.SubjectTaught.StartsWith(searchText));
                searchResult = searchResults.Select(x => new TeacherModel { Id = x.Id, FirstName = x.FirstName, LastName = x.LastName, Email = x.Email, PhoneNumber = x.PhoneNumber }).ToList();
            }
            return View("~/Views/Teacher/List.cshtml", searchResult);
        }
        public IActionResult Save(TeacherModel teacher,string type)
        {
            if (type.Equals("Cancel"))
            {
                return RedirectToAction("List");
            }

            if (ModelState.IsValid)
            {
                var teacherEntity = new Teacher
                {
                    FirstName = teacher.FirstName,
                    LastName = teacher.LastName,
                    Email = teacher.Email,
                    PhoneNumber = teacher.PhoneNumber,
                    RoomNumber = teacher.RoomNumber,
                    SubjectTaught = teacher.SubjectTaught
                };
                bool hasExist = HasEmail(teacher.Email);
                if (!hasExist)
                {
                    _context.Teachers.Add(teacherEntity);
                    _context.SaveChanges();
                }
                else
                {
                    ViewBag.Error = "Email Exists Already!";
                    return SetDefaultView(teacher);
                }
            }
            else
            {
                ViewBag.Error = "Enter the required detail";
                return SetDefaultView(teacher);
            }
            return RedirectToAction("List");
        }

        private IActionResult SetDefaultView(TeacherModel teacher)
        {
            var testModel = new TestModel();
            testModel.Teacher = teacher;
            return View("~/Views/Teacher/Test.cshtml", testModel);
        }


        private bool HasEmail(string email)
        {
            return _context.Teachers.Any(x => x.Email == email);
        }

        public IActionResult Import(IFormFile postedFile)
        {
            if (postedFile != null)
            {
                //Create a Folder.
                string path = Path.Combine(this.Environment.WebRootPath, "Uploads");
                if (!System.IO.Directory.Exists(path))
                {
                    System.IO.Directory.CreateDirectory(path);
                }

                //Save the uploaded Excel file.
                string fileName = Path.GetFileName(postedFile.FileName);
                string filePath = Path.Combine(path, fileName);
                using (FileStream stream = new FileStream(filePath, FileMode.Create))
                {
                    postedFile.CopyTo(stream);                   
                }
                string[] read;
                StreamReader sr = new StreamReader(filePath);
                string data = sr.ReadLine();
                char[] seperators = { ',' };
                List<Teacher> teachers = new List<Teacher>();
                while ((data = sr.ReadLine()) != null)
                {
                    read = data.Split(seperators, StringSplitOptions.RemoveEmptyEntries);
                    string firstName = read[0];
                    string lastName = read[1];
                    string profilePicture = read[2];
                    string emailAddress = read[3];
                    string phoneNumber = read[4];
                    string roomNumber = read[5];
                    List<string> subjects = new List<string>();
                    for (int i = 6; i < read.Length; i++)
                    {
                        subjects.Add(read[i]);
                    }
                    string subject = string.Join(",", subjects);
                    var teacher = new Teacher
                    {
                        FirstName = firstName,
                        LastName = lastName,
                        Email = emailAddress,
                        PhoneNumber = phoneNumber,
                        RoomNumber = roomNumber,
                        SubjectTaught = subject,
                        ProfilePicture = profilePicture
                    };
                    teachers.Add(teacher);
                }
                _context.Teachers.AddRange(teachers);
                _context.SaveChanges();
            }
            return RedirectToAction("List");
        } 
    }
}
