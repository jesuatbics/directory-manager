using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Directory.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Directory.Views.Login
{
    public class UserLoginModel : PageModel
    {
        [BindProperty]
        public LoginModel LoginModel { get; set; }
        public void OnGet()
        {
            LoginModel = new LoginModel();
        }
    }
}