using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Directory.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Directory.Views.Teacher
{
    public class TestModel : PageModel
    {
        [BindProperty]
        public TeacherModel Teacher { get; set; }
        public void OnGet()
        {
            Teacher = new TeacherModel();
        }
    }
}